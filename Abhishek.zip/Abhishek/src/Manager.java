
public class Manager {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
        //Calling the object of the class SortPrice
		SortPrice sp= new SortPrice();
		
		sp.addItems();
		sp.displayItems();
		sp.sort();
		sp.displayItems();
		
	}

}
